
# coding: utf-8

# In[ ]:


import numpy as np


# In[ ]:


def print_maclaurin_table(*, term, x, max_terms=15):
    # Don't print tables that are ridiculously long:
    if max_terms >= 100:
        print("Too many terms; for this demo use less than 100 terms!")
        return

    # Check to see if NumPy supports this function:
    # We expect the function to be named the same as the real
    # mathematical function but with "_term" on the end.
    function_name = term.__name__.replace("_term", "")
    if not hasattr(np, function_name):
        # We don't know what this function is; abort.
        print("Unknown function '{0}'!".format(function_name))
        return

    # Now we work out the real value of f(x):
    real_function = getattr(np, function_name)  # i.e. if called with `term=sin_term`, then getattr
    real_value = real_function(x)               # will return np.sin and we can then do np.sin(x)
    
    # Then we work out the values of the terms:
    terms = np.zeros(max_terms)  # this gives us an empty array
    for r in range(max_terms):
        terms[r] = term(r=r, x=x)  # we set each value using the term function provided
    
    # Then we can work out the cumulative sum of the terms,
    # and the differences from the real value:
    result_to_r = np.cumsum(terms)
    differences = result_to_r - real_value
    
    #####
    # Everything below here in this function is just to print the table:
    #####

    # These string and width values are used to make the table look nice:
    widest_num_width = max(len(str(int(real_value))), len(str(int(result_to_r[-1]))))
    column_width = 16 + widest_num_width
    num_width = column_width - 2  # numbers are two spaces smaller than the column width
    column_heading = "{0}(x) so far".format(function_name)  # add function name to column
    table_heading = "| Term |{0:^{width}}|{1:^{width}}|{2:^{width}}|".format("Term Value", column_heading,
                                                                             "Error", width=column_width)
    table_separator = "|" + ("-" * 6) + (("|" + ("-" * column_width)) * 3) + "|"
    table_base = ("-" * 8) + (" " * column_width) + ("-" * (column_width + 2))
    title = "Evaluating {0}({1})".format(function_name, x)
    title = title.center(len(table_separator))  # centre align to width of table
    title = "|{0:s}|".format(title[1:-1])  # add |'s to each end of the title

    # Then we actually print the top of the table:
    print(table_separator.replace("|", "-"))
    print(title)
    print(table_separator.replace("|", "-"))
    print(table_heading)
    print(table_separator)

    # Now we print the rows of the table:
    for r in range(max_terms):
        term_number = r + 1  # The sum goes from 0 to infinity, but humans count from 1
        # Print a row of the table, with the three values formatted nicely:
        print("|  {0:-2d}  | {1: {width}.12f} | {2: {width}.12f} | {3:+{width}.12f} |"
              .format(term_number, terms[r], result_to_r[r], differences[r], width=num_width))

    # Then we print the real value at the bottom:
    print(table_separator)
    print("| Real |{0}| {1: {width}.12f} |".format(" " * column_width, real_value, width=num_width))
    print(table_base)


# In[ ]:


def exp_term(r, x):
    return np.power(x, r) / np.math.factorial(r)

#####

def sin_term(r, x):
    return np.power(-1, r) * np.power(x, 2 * r + 1) / np.math.factorial(2 * r + 1)

def cos_term(r, x):
    return np.power(-1, r) * np.power(x, 2 * r) / np.math.factorial(2 * r)

def cosh_term(r, x):
    return np.power(x, 2 * r) / np.math.factorial(2 * r)

def sinh_term(r, x):
    return np.power(x, 2 * r + 1) / np.math.factorial(2 * r + 1)


# In[ ]:


print_maclaurin_table(x=1, term=exp_term)

