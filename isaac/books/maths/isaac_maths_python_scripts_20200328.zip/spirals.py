
# coding: utf-8

# In[ ]:


import numpy as np
import matplotlib.pyplot as plt


# In[ ]:


# Define some useful parameters:

theta_min = 0
theta_max = 6 * np.pi
points_per_radian = 20

# Set up the array of points we're going to sample at to create a plot:

theta_range = theta_max - theta_min
theta_array = np.linspace(theta_min, theta_max, int(theta_range * points_per_radian))

# Equation of the spiral:

r_array = theta_array / np.pi  # r(theta) = theta/pi

# Initialise a new figure and then plot the spiral:

plt.figure(figsize=(6, 6))  # 'figsize' is the width and height
plt.polar(theta_array, r_array, linewidth=3, color='blue')  # the first two arguments are the angle
                                                            # and the radius at that angle: r(theta)
    
# Label the axes:

plt.thetagrids(np.arange(0, 360, 90))          # set the positions of the theta labels
plt.gca().set_rlabel_position(0)               # set the angle of the radius labels
plt.gca().grid(linestyle='--', linewidth=0.5)  # make the grid thin and dashed

# Display the result:

plt.tight_layout()
plt.show()

