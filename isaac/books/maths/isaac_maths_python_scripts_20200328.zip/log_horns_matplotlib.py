
# coding: utf-8

# In[ ]:


import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm

get_ipython().run_line_magic('matplotlib', 'notebook')


# In[ ]:


def draw_log_horn(*, b, w_0, alpha_min=0, alpha_max=2*np.pi, theta_min=-6*np.pi, theta_max=0, divisions_per_radian=8):

    # Check the inputs are sensible:

    if alpha_min > alpha_max:
        print("Error: alpha_min must be smaller than alpha_max!")
        return
    if theta_min > theta_max:
        print("Error: theta_min must be smaller than theta_max!")
        return
    if not(divisions_per_radian > 0 and isinstance(divisions_per_radian, int)):
        print("Error: the number of divisions per radian must be a positive integer!")
        return

    # Set up the grid of points we're going to sample at to create a surface:

    alpha_range = alpha_max - alpha_min
    alpha_array = np.linspace(alpha_min, alpha_max, int(alpha_range * divisions_per_radian))
    
    theta_range = theta_max - theta_min
    theta_array = np.linspace(theta_min, theta_max, int(theta_range * divisions_per_radian))
    
    alpha_grid, theta_grid = np.meshgrid(alpha_array, theta_array)

    # Work out the values of r and w at each point:

    r_0 = 1
    r = r_0 * np.exp(b * theta_grid)  # underlying log spiral:     r = r_0 * exp(b*theta)
    w = w_0 * np.exp(b * theta_grid)  # circular sectional radius: w = w_0*exp(b*theta)

    # Convert from angular coordinates to linear coordinates (note r and w are arrays here):

    x = (r + w * np.cos(alpha_grid)) * np.cos(theta_grid)  # x = (r + w*cos(alpha))*cos(theta)
    y = (r + w * np.cos(alpha_grid)) * np.sin(theta_grid)  # y = (r + w*cos(alpha))*sin(theta)
    z = w * np.sin(alpha_grid)                             # z = w*sin(alpha)

    # Configure matplotlib plot:

    fig = plt.figure(figsize=(8, 8))  # 'figsize' is the width and height
    ax = fig.gca(projection='3d')  # need to have imported 'Axes3D' for this to work
    ax.view_init(45, 60)  # set the initial view angles
    ax.w_xaxis.set_pane_color((1, 1, 1))  # set the background color on the x-axis to white
    ax.w_yaxis.set_pane_color((1, 1, 1))  # repeat for y-axis
    ax.w_zaxis.set_pane_color((1, 1, 1))  # repeat for z-axis
    _axis_settings = {'grid': {'color': (0, 0, 0.8), 'linewidth': 0.3, 'linestyle': '--'}, 'color': (0, 0, 0, 1)}
    ax.w_xaxis._axinfo.update(_axis_settings)  # change the grid settings for x
    ax.w_yaxis._axinfo.update(_axis_settings)  # repeat for y
    ax.w_zaxis._axinfo.update(_axis_settings)  # repeat for z

    # Add the log horn surface to the plot:

    ax.plot_surface(x, y, z, linewidth=0, antialiased=True, cmap=cm.Spectral_r, rstride=1, cstride=1)
    # The first three arguments are the x, y, z arrays
    # `linewidth=0` reduces the size of the lines joining the sample points on the surface
    # `antialiased=True` smooths the surface
    # `cmap` is the colour mapping: `cm.Spectral_r` is good, but also `cm.PuRd` or `cm.ocean`
    # `rstride=1` and `cstride=1` ensure all sample points are plotted
    
    
    # Force the aspect ratio equal for all axes:

    max_range = np.array([x.max() - x.min(), y.max() - y.min(), z.max() - z.min()]).max() / 2
    mid_x = (x.max() + x.min()) / 2
    mid_y = (y.max() + y.min()) / 2
    mid_z = (z.max() + z.min()) / 2
    ax.set_xlim(mid_x - max_range, mid_x + max_range)
    ax.set_ylim(mid_y - max_range, mid_y + max_range)
    ax.set_zlim(mid_z - max_range, mid_z + max_range)

    # Display the result:

    plt.tight_layout()
    plt.show()


# In[ ]:


draw_log_horn(b=0.2, w_0=0.5)

