
# coding: utf-8

# In[ ]:


import numpy as np
import plotly.offline as py
import plotly.graph_objs as go

py.init_notebook_mode()


# In[ ]:


def draw_log_horn(*, b, w_0, alpha_min=0, alpha_max=2*np.pi, theta_min=-6*np.pi, theta_max=0, divisions_per_radian=8):

    # Check the inputs are sensible:

    if alpha_min > alpha_max:
        print("Error: alpha_min must be smaller than alpha_max!")
        return
    if theta_min > theta_max:
        print("Error: theta_min must be smaller than theta_max!")
        return
    if not(divisions_per_radian > 0 and isinstance(divisions_per_radian, int)):
        print("Error: the number of divisions per radian must be a positive integer!")
        return

    # Set up the grid of points we're going to sample at to create a surface:

    alpha_range = alpha_max - alpha_min
    alpha_array = np.linspace(alpha_min, alpha_max, int(alpha_range * divisions_per_radian))
    
    theta_range = theta_max - theta_min
    theta_array = np.linspace(theta_min, theta_max, int(theta_range * divisions_per_radian))
    
    alpha_grid, theta_grid = np.meshgrid(alpha_array, theta_array)

    # Work out the values of r and w at each point:

    r_0 = 1
    r = r_0 * np.exp(b * theta_grid)  # underlying log spiral:     r = r_0 * exp(b*theta)
    w = w_0 * np.exp(b * theta_grid)  # circular sectional radius: w = w_0 * exp(b*theta)

    # Convert from angular coordinates to linear coordinates (note r and w are arrays here):

    x = (r + w * np.cos(alpha_grid)) * np.cos(theta_grid)  # x = (r + w*cos(alpha))*cos(theta)
    y = (r + w * np.cos(alpha_grid)) * np.sin(theta_grid)  # y = (r + w*cos(alpha))*sin(theta)
    z = w * np.sin(alpha_grid)                             # z = w*sin(alpha)

    # Configure the Plotly plot:

    surface = go.Surface(x=x, y=y, z=z)
    data = [surface]
    layout = go.Layout(
        height=800,
        scene=dict(
            xaxis=dict(
                gridcolor='rgb(0, 0, 255)',
                zerolinecolor='rgb(255, 0, 0)',
                showbackground=False,
                backgroundcolor='rgb(230, 230, 230)'
            ),
            yaxis=dict(
                gridcolor='rgb(0, 0, 255)',
                zerolinecolor='rgb(255, 0, 0)',
                showbackground=False,
                backgroundcolor='rgb(230, 230, 230)'
            ),
            zaxis=dict(
                gridcolor='rgb(0, 0, 255)',
                zerolinecolor='rgb(255, 0, 0)',
                showbackground=False,
                backgroundcolor='rgb(230, 230, 230)'
            )
        )
    )
    fig = go.Figure(data=data, layout=layout)

    # Plot it:

    py.iplot(fig)


# In[ ]:


draw_log_horn(b=0.2, w_0=0.5)

