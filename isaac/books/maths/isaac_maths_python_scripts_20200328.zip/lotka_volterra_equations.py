
# coding: utf-8

# In[ ]:


import numpy as np
import scipy.integrate
import matplotlib.pyplot as plt

get_ipython().run_line_magic('matplotlib', 'notebook')


# In[ ]:


def population_derivatives(populations, t, beta):
    # Extract y and z from the list:
    y = populations[0]
    z = populations[1]

    # Evaluate the derivatives at this point:
    y_prime = (z - beta) * y
    z_prime = (1 - y) * z

    # Return the vector of derivatives (as a list):
    return [y_prime, z_prime]


# In[ ]:


# Set the one parameter left after scaling:
beta = 0.7

# Set the initial conditions for y and z:
y_0 = 0.1
z_0 = 0.7

# Decide the times we want to know the values of y and z at:
t_min = 0
t_max = 16
number_of_samples = 1000  # how many points to sample the populations at for plotting
t = np.linspace(t_min, t_max, number_of_samples)  # points in time to evaluate populations at

# Set the initial populations:
initial_populations = np.array([y_0, z_0])

# Integrate the two differential equations at the same time:
# The function `odeint(...)` takes the function to integrate as its first argument,
# initial conditions second, the time array third,
# and then `args`, the additional arguments to population_derivatives(...)
solution_list = scipy.integrate.odeint(population_derivatives, initial_populations, t, args=(beta,))

# Unpack the solution vector into its component arrays:
y = solution_list[:, 0]  # extract column 0, the y values
z = solution_list[:, 1]  # extract column 1, the z values

# Plot y and z values against time on the same plot:
plt.figure()
plt.title("The Lotka-Volterra Equations")
plt.plot(t, y, color='r', label='y(t)')
plt.plot(t, z, color='k', label='z(t)')
plt.legend(loc='best')  # add a plot legend
plt.xlabel('t', style='italic')  # add x-axis label
plt.ylabel('y, z', style='italic')  # add y-axis label
plt.gca().set_xlim(t[0], t[-1])  # show only the time range we calculated
plt.gca().set_ylim(bottom=0)  # populations cannot be negative, so y,z > 0

# Display the result:
plt.tight_layout()
plt.show()

